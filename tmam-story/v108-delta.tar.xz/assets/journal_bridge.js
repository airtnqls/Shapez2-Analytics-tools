/* Additive journal tab: never resets a query, worker, placement or experiment. */
'use strict';
(()=>{
 const button=document.getElementById('navBlog'),panel=document.getElementById('journalWorkspace'),frame=document.getElementById('journalFrame');
 let previous='navSearch',scroll=0,initialized=false;
 function open(){if(document.body.classList.contains('journalMode'))return;previous=document.querySelector('.workspaceNav .navActive')?.id||'navSearch';scroll=window.scrollY;document.querySelectorAll('dialog[open]').forEach(d=>d.close());document.body.classList.add('journalMode');document.querySelectorAll('.workspaceNav button').forEach(b=>b.classList.toggle('navActive',b===button));button.setAttribute('aria-expanded','true');panel.hidden=false;
  if(!initialized){let language='ko';try{const chosen=localStorage.getItem('tmam-blog-lang');const saved=JSON.parse(localStorage.getItem('tmam-journal-progress-v1')||'null');if(chosen==='en'||(chosen!=='ko'&&saved?.lang==='en'))language='en';}catch{}frame.src='blog/'+language+'/index.html';initialized=true;}document.getElementById('journalBack').focus({preventScroll:true});
 }
 function close(){if(!document.body.classList.contains('journalMode'))return;document.body.classList.remove('journalMode');button.setAttribute('aria-expanded','false');panel.hidden=true;document.querySelectorAll('.workspaceNav button').forEach(b=>b.classList.toggle('navActive',b.id===previous));window.scrollTo(0,scroll);}
 button.addEventListener('click',open);document.getElementById('journalBack').addEventListener('click',()=>{close();document.getElementById(previous)?.focus({preventScroll:true});});
 ['navSearch','navSimulator','navDag','navLibrary','homeLink'].forEach(id=>document.getElementById(id)?.addEventListener('click',close,{capture:true}));
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow||!e.data||typeof e.data!=='object')return;if(e.data.type==='tmam:journal:return'){close();document.getElementById(previous)?.focus({preventScroll:true});}});
 window.TMAMJournal=Object.freeze({open,close,isOpen:()=>document.body.classList.contains('journalMode')});
})();
